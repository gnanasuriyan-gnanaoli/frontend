output = []

async function screenCapture(){
  const promise = await chrome.tabs.captureVisibleTab();
  console.log(promise);
  return promise;
}

async function injectScripts(tab){
  const promise = await chrome.scripting.executeScript({
    target: {tabId: tab.id},
    files: ['js/inject-script.js', 'js/highlight.js']
  });
  console.log(promise);
  return promise;
}

async function insertCss(tab){
  const promise = await chrome.scripting.insertCSS({
    target: {tabId: tab.id},
    files: ['css/inject-css.css'],
  });

  console.log(promise);
  return promise;
}

chrome.action.onClicked.addListener((tab) => {
  if(!tab.url.includes("chrome://")) {
    injectScripts(tab);
    insertCss(tab);
  }
});


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 2. A page requested user data, respond with a copy of `user`
  event =  message.event;
  if(event.type === 'focusout'){
    if(['text', 'textarea', 'select', 'radio'].includes(event.target.type)){
      recordEvent(event);
    }
  }
  if (event.type === 'click' && !(['text', 'textarea', 'select', 'radio'].includes(event.target.type))) {
    recordEvent(event);
  }
  
  
  // chrome.tabs.captureVisibleTab().then((message) =>{
  //   chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
  //     chrome.tabs.sendMessage(tabs[0].id, {type: 'screenshot', captured: message}, function(response) {
  //       console.log(response);
  //     });
  //   });
  // });
  console.log(output);
  sendResponse({"captured": output});
});

function recordEvent(event){
  screenCapture().then(screenshot => {
    output.push({
      action: 'input',
      type: event.target.type,
      value: event.target.value,
      label: event.target.label,
      screenshot: screenshot
    });
  })
}


function callbackFromNewTab(tab){
  // debugger
  console.log(`new tab ${tab.id}`);
}

