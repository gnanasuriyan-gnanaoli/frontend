
console.log('inject-script reached');

document.getElementById('body');

var actions = document.createElement('div');
actions.className = 'htg-actions'
document.body.appendChild(actions);
var id = chrome.runtime.id;
actions.innerHTML = `
  <img src='chrome-extension://${id}/assets/complete.svg' alt="">
  <button class='resume'>
  </button>
  <button class='pause'>
  </button>
  <button class='discard'>
  </button>
`
function serialiseEvent(event){
  if(event.target.labels && event.target.labels.length)
    var label = event.target.labels[0].innerText;
  return {event: {type: event.type, target: { value: event.target.value, type: event.target.type, label: label }}}
}

function appendScreenshot(screenshot){
  var image = document.createElement('img');
  image.className = 'htg-screenshot'
  image.src = screenshot;
  document.body.appendChild(image);
}

document.addEventListener('click', (event) => {
  // send message to extension
  chrome.runtime.sendMessage(serialiseEvent(event), (response) => {
    // 3. Got an asynchronous response with the data from the service worker
    appendScreenshot(response.captured[response.captured.length - 1].screenshot);
    console.log('received user data', response);
  });
})

window.addEventListener('focusout', function (event) {
      chrome.runtime.sendMessage(serialiseEvent(event), (response) => {
      // 3. Got an asynchronous response with the data from the service worker
      console.log('received user data', response);
      appendScreenshot(response.captured[response.captured.length - 1].screenshot);
    });
}, true);

chrome.runtime.onMessage.addListener(
  // receive message from extension
  function(request, sender, sendResponse) {
    console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension");
    console.log(request);
    if(request.type === 'screenshot'){
      appendScreenshot(request.captured);
    }
    sendResponse({farewell: "goodbye"});
  }
);
// chrome-extension://hhnigonbiimcifcbammppemblmnogmfd/assets/complete.svg
